-- Works in PostgreSQL (SET search_path TO pharma, public) and SQLite.
-- Annual totals, preserving the source's signed sales and reporting missing values.
SELECT year, COUNT(*) AS row_count, SUM(units_sold) AS units_sold,
 SUM(sales_consumer_rial) AS sales_consumer_rial,
 SUM(CASE WHEN sales_consumer_rial IS NULL THEN 1 ELSE 0 END) AS missing_value_rows
FROM fact_sales GROUP BY year ORDER BY year;

-- Same top 10 suppliers by 1402 consumer sales value; both years' quantities/values.
WITH annual AS (
 SELECT supplier_id,year,SUM(sales_consumer_rial) AS value,SUM(units_sold) AS volume
 FROM fact_sales WHERE year IN (1401,1402) GROUP BY supplier_id,year
), top10 AS (
 SELECT supplier_id,value,volume FROM annual WHERE year=1402 AND supplier_id IS NOT NULL
 ORDER BY value DESC,supplier_id LIMIT 10
)
SELECT c.company_name,t.value AS value_1402,COALESCE(a.value,0) AS value_1401,
 t.value-COALESCE(a.value,0) AS value_change,t.volume AS volume_1402,
 COALESCE(a.volume,0) AS volume_1401,t.volume-COALESCE(a.volume,0) AS volume_change
FROM top10 t JOIN dim_company c ON c.company_id=t.supplier_id
LEFT JOIN annual a ON a.supplier_id=t.supplier_id AND a.year=1401
ORDER BY t.value DESC,t.supplier_id;

SELECT year,COALESCE(atc_l1,'Unknown') AS atc_l1,
 SUM(sales_consumer_rial) AS value,SUM(units_sold) AS volume
FROM v_sales_dashboard GROUP BY year,COALESCE(atc_l1,'Unknown') ORDER BY year,atc_l1;
